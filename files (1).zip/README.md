# User Data Management System 👤

A simple, beginner-friendly web application to store and manage user information.

## Features ✨

- **Easy Registration**: Simple form to register new users
- **User Information**: Store full name, email, phone, address, city, country, and date of birth
- **Search Functionality**: Search users by name or email
- **Local Storage**: All data is saved locally in your browser
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Delete Users**: Remove user records when needed
- **Beautiful UI**: Modern and user-friendly interface

## Getting Started 🚀

1. **Download the files**:
   - `index.html`
   - `style.css`
   - `script.js`

2. **Open in browser**:
   - Simply open `index.html` in your web browser
   - No installation or server required!

3. **Start registering users**:
   - Fill out the registration form
   - Click "Register User"
   - View all registered users below

## How It Works 🔧

- **Form Submission**: Enter user details and click submit
- **Local Storage**: Data is automatically saved to your browser's local storage
- **Display**: All users are displayed in card format
- **Search**: Use the search box to find users by name or email
- **Delete**: Click the delete button on any user card to remove them

## Data Stored 📋

- Full Name (Required)
- Email Address (Required)
- Phone Number (Required)
- Address (Optional)
- City (Required)
- Country (Required)
- Date of Birth (Optional)
- Registration Date (Automatic)

## Browser Support 🌐

- Chrome
- Firefox
- Safari
- Edge
- Any modern browser with JavaScript enabled

## Note 📝

- Data is stored locally in your browser
- Clearing browser cache will delete all data
- For a production system with permanent data storage, use a backend database

## Future Enhancements 🎯

- Backend database integration
- User authentication
- Data export to CSV/PDF
- User profile editing
- Email verification

---

**Created**: 2026
**Version**: 1.0