from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from contextlib import contextmanager
import os
from dotenv import load_dotenv

# Import models and schemas
from models import Base, User
from schemas import UserCreate, UserUpdate, UserResponse
from database import DATABASE_URL

load_dotenv()

# Create FastAPI app
app = FastAPI(
    title="User Data Management System",
    description="A beginner-friendly API to manage user data",
    version="1.0.0"
)

# Configure CORS (allow frontend to access backend)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database setup
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Create tables
Base.metadata.create_all(bind=engine)

# Dependency to get database session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ==================== ROUTES ====================

# Root endpoint
@app.get("/", tags=["Root"])
async def root():
    """Welcome endpoint"""
    return {
        "message": "Welcome to User Data Management System API",
        "version": "1.0.0",
        "endpoints": {
            "users": "/users",
            "create_user": "POST /users",
            "get_user": "GET /users/{user_id}",
            "update_user": "PUT /users/{user_id}",
            "delete_user": "DELETE /users/{user_id}",
            "search_users": "GET /users/search?query={query}",
            "docs": "/docs"
        }
    }

# ==================== CREATE USER ====================
@app.post("/users", response_model=UserResponse, status_code=status.HTTP_201_CREATED, tags=["Users"])
async def create_user(user: UserCreate, db: Session = None):
    """
    Create a new user
    
    **Required fields:**
    - full_name
    - email
    - phone
    - city
    - country
    
    **Optional fields:**
    - address
    - date_of_birth
    """
    db = SessionLocal() if db is None else db
    
    # Check if email already exists
    existing_user = db.query(User).filter(User.email == user.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Create new user
    db_user = User(**user.dict())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    return db_user

# ==================== GET ALL USERS ====================
@app.get("/users", response_model=list[UserResponse], tags=["Users"])
async def get_all_users(skip: int = 0, limit: int = 100, db: Session = None):
    """
    Get all registered users with pagination
    
    **Query parameters:**
    - skip: Number of users to skip (default: 0)
    - limit: Maximum number of users to return (default: 100)
    """
    db = SessionLocal() if db is None else db
    users = db.query(User).offset(skip).limit(limit).all()
    return users

# ==================== GET USER BY ID ====================
@app.get("/users/{user_id}", response_model=UserResponse, tags=["Users"])
async def get_user(user_id: int, db: Session = None):
    """Get a specific user by ID"""
    db = SessionLocal() if db is None else db
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return user

# ==================== SEARCH USERS ====================
@app.get("/users/search/query", response_model=list[UserResponse], tags=["Users"])
async def search_users(query: str = "", db: Session = None):
    """
    Search users by name or email
    
    **Query parameters:**
    - query: Search term (searches in full_name and email)
    """
    db = SessionLocal() if db is None else db
    
    if not query:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Search query cannot be empty"
        )
    
    users = db.query(User).filter(
        (User.full_name.ilike(f"%{query}%")) |
        (User.email.ilike(f"%{query}%"))
    ).all()
    
    return users

# ==================== UPDATE USER ====================
@app.put("/users/{user_id}", response_model=UserResponse, tags=["Users"])
async def update_user(user_id: int, user_update: UserUpdate, db: Session = None):
    """Update user information"""
    db = SessionLocal() if db is None else db
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Update only provided fields
    update_data = user_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(user, field, value)
    
    db.commit()
    db.refresh(user)
    
    return user

# ==================== DELETE USER ====================
@app.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Users"])
async def delete_user(user_id: int, db: Session = None):
    """Delete a user by ID"""
    db = SessionLocal() if db is None else db
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    db.delete(user)
    db.commit()
    
    return None

# ==================== GET STATISTICS ====================
@app.get("/stats", tags=["Statistics"])
async def get_statistics(db: Session = None):
    """Get system statistics"""
    db = SessionLocal() if db is None else db
    
    total_users = db.query(User).count()
    
    return {
        "total_users": total_users,
        "api_version": "1.0.0",
        "status": "online"
    }

# ==================== HEALTH CHECK ====================
@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "message": "API is running successfully"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)