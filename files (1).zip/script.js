// Initialize users array from localStorage
let users = JSON.parse(localStorage.getItem('users')) || [];

// Get DOM elements
const userForm = document.getElementById('userForm');
const usersList = document.getElementById('usersList');
const userCount = document.getElementById('userCount');
const searchInput = document.getElementById('searchInput');
const successMessage = document.getElementById('successMessage');

// Event listeners
userForm.addEventListener('submit', handleFormSubmit);
searchInput.addEventListener('input', handleSearch);

// Handle form submission
function handleFormSubmit(e) {
    e.preventDefault();

    const formData = {
        id: Date.now(), // Simple unique ID
        fullName: document.getElementById('fullName').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        address: document.getElementById('address').value,
        city: document.getElementById('city').value,
        country: document.getElementById('country').value,
        dob: document.getElementById('dob').value,
        registeredDate: new Date().toLocaleDateString()
    };

    // Add user to array
    users.push(formData);

    // Save to localStorage
    localStorage.setItem('users', JSON.stringify(users));

    // Show success message
    showSuccessMessage();

    // Reset form
    userForm.reset();

    // Update display
    displayUsers();
}

// Display all users
function displayUsers(usersToDisplay = users) {
    usersList.innerHTML = '';
    userCount.textContent = usersToDisplay.length;

    if (usersToDisplay.length === 0) {
        usersList.innerHTML = '<p class="no-users">No users registered yet. Add one using the form above!</p>';
        return;
    }

    usersToDisplay.forEach(user => {
        const userCard = document.createElement('div');
        userCard.className = 'user-card';
        userCard.innerHTML = `
            <h3>${escapeHtml(user.fullName)}</h3>
            <div class="user-info">
                <strong>📧 Email:</strong> ${escapeHtml(user.email)}
            </div>
            <div class="user-info">
                <strong>📱 Phone:</strong> ${escapeHtml(user.phone)}
            </div>
            <div class="user-info">
                <strong>📍 City:</strong> ${escapeHtml(user.city)}
            </div>
            <div class="user-info">
                <strong>🌍 Country:</strong> ${escapeHtml(user.country)}
            </div>
            ${user.address ? `<div class="user-info"><strong>🏠 Address:</strong> ${escapeHtml(user.address)}</div>` : ''}
            ${user.dob ? `<div class="user-info"><strong>🎂 DOB:</strong> ${escapeHtml(user.dob)}</div>` : ''}
            <div class="user-info">
                <strong>📅 Registered:</strong> ${user.registeredDate}
            </div>
            <div class="user-actions">
                <button class="btn-delete" onclick="deleteUser(${user.id})">🗑️ Delete</button>
            </div>
        `;
        usersList.appendChild(userCard);
    });
}

// Search users
function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase();

    const filteredUsers = users.filter(user => 
        user.fullName.toLowerCase().includes(searchTerm) ||
        user.email.toLowerCase().includes(searchTerm)
    );

    displayUsers(filteredUsers);
}

// Delete user
function deleteUser(id) {
    if (confirm('Are you sure you want to delete this user?')) {
        users = users.filter(user => user.id !== id);
        localStorage.setItem('users', JSON.stringify(users));
        displayUsers();
    }
}

// Show success message
function showSuccessMessage() {
    successMessage.style.display = 'block';
    setTimeout(() => {
        successMessage.style.display = 'none';
    }, 3000);
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Initial display
displayUsers();