// API BASE URL - Change this if your backend is on a different server
const API_BASE_URL = 'http://localhost:8000';

// Get DOM elements
const userForm = document.getElementById('userForm');
const usersList = document.getElementById('usersList');
const userCount = document.getElementById('userCount');
const searchInput = document.getElementById('searchInput');
const successMessage = document.getElementById('successMessage');

// Event listeners
userForm.addEventListener('submit', handleFormSubmit);
searchInput.addEventListener('input', handleSearch);

// Load users on page load
window.addEventListener('load', loadUsers);

// Handle form submission
async function handleFormSubmit(e) {
    e.preventDefault();

    const userData = {
        full_name: document.getElementById('fullName').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        address: document.getElementById('address').value || null,
        city: document.getElementById('city').value,
        country: document.getElementById('country').value,
        date_of_birth: document.getElementById('dob').value || null
    };

    try {
        const response = await fetch(`${API_BASE_URL}/users`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData)
        });

        if (!response.ok) {
            const error = await response.json();
            alert('Error: ' + error.detail);
            return;
        }

        showSuccessMessage();
        userForm.reset();
        loadUsers();
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to register user. Make sure the backend server is running.');
    }
}

// Load all users from backend
async function loadUsers() {
    try {
        const response = await fetch(`${API_BASE_URL}/users`);
        
        if (!response.ok) {
            throw new Error('Failed to fetch users');
        }

        const users = await response.json();
        displayUsers(users);
    } catch (error) {
        console.error('Error:', error);
        usersList.innerHTML = '<p class="no-users">Failed to load users. Make sure the backend server is running at ' + API_BASE_URL + '</p>';
    }
}

// Display users
function displayUsers(users) {
    usersList.innerHTML = '';
    userCount.textContent = users.length;

    if (users.length === 0) {
        usersList.innerHTML = '<p class="no-users">No users registered yet. Add one using the form above!</p>';
        return;
    }

    users.forEach(user => {
        const createdDate = new Date(user.created_at).toLocaleDateString();
        const userCard = document.createElement('div');
        userCard.className = 'user-card';
        userCard.innerHTML = `
            <h3>${escapeHtml(user.full_name)}</h3>
            <div class="user-info">
                <strong>📧 Email:</strong> ${escapeHtml(user.email)}
            </div>
            <div class="user-info">
                <strong>📱 Phone:</strong> ${escapeHtml(user.phone)}
            </div>
            <div class="user-info">
                <strong>📍 City:</strong> ${escapeHtml(user.city)}
            </div>
            <div class="user-info">
                <strong>🌍 Country:</strong> ${escapeHtml(user.country)}
            </div>
            ${user.address ? `<div class="user-info"><strong>🏠 Address:</strong> ${escapeHtml(user.address)}</div>` : ''}
            ${user.date_of_birth ? `<div class="user-info"><strong>🎂 DOB:</strong> ${escapeHtml(user.date_of_birth)}</div>` : ''}
            <div class="user-info">
                <strong>📅 Registered:</strong> ${createdDate}
            </div>
            <div class="user-actions">
                <button class="btn-delete" onclick="deleteUser(${user.id})">🗑️ Delete</button>
            </div>
        `;
        usersList.appendChild(userCard);
    });
}

// Search users
async function handleSearch(e) {
    const searchTerm = e.target.value.trim();

    if (!searchTerm) {
        loadUsers();
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/users/search/query?query=${encodeURIComponent(searchTerm)}`);
        
        if (!response.ok) {
            throw new Error('Search failed');
        }

        const users = await response.json();
        displayUsers(users);
    } catch (error) {
        console.error('Error:', error);
    }
}

// Delete user
async function deleteUser(userId) {
    if (confirm('Are you sure you want to delete this user?')) {
        try {
            const response = await fetch(`${API_BASE_URL}/users/${userId}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Failed to delete user');
            }

            loadUsers();
        } catch (error) {
            console.error('Error:', error);
            alert('Failed to delete user');
        }
    }
}

// Show success message
function showSuccessMessage() {
    successMessage.style.display = 'block';
    setTimeout(() => {
        successMessage.style.display = 'none';
    }, 3000);
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}