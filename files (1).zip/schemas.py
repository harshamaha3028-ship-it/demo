from pydantic import BaseModel, EmailStr, Field
from datetime import date, datetime
from typing import Optional

class UserCreate(BaseModel):
    """Schema for creating a new user"""
    full_name: str = Field(..., min_length=2, max_length=100, description="User's full name")
    email: EmailStr = Field(..., description="User's email address")
    phone: str = Field(..., min_length=7, max_length=20, description="User's phone number")
    address: Optional[str] = Field(None, max_length=255, description="User's address")
    city: str = Field(..., min_length=2, max_length=50, description="User's city")
    country: str = Field(..., min_length=2, max_length=50, description="User's country")
    date_of_birth: Optional[date] = Field(None, description="User's date of birth")
    
    class Config:
        json_schema_extra = {
            "example": {
                "full_name": "John Doe",
                "email": "john@example.com",
                "phone": "+1-234-567-8900",
                "address": "123 Main Street",
                "city": "New York",
                "country": "United States",
                "date_of_birth": "1990-01-15"
            }
        }

class UserUpdate(BaseModel):
    """Schema for updating a user"""
    full_name: Optional[str] = Field(None, min_length=2, max_length=100)
    phone: Optional[str] = Field(None, min_length=7, max_length=20)
    address: Optional[str] = Field(None, max_length=255)
    city: Optional[str] = Field(None, min_length=2, max_length=50)
    country: Optional[str] = Field(None, min_length=2, max_length=50)
    date_of_birth: Optional[date] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "phone": "+1-234-567-8901",
                "city": "Los Angeles"
            }
        }

class UserResponse(BaseModel):
    """Schema for user response"""
    id: int
    full_name: str
    email: str
    phone: str
    address: Optional[str]
    city: str
    country: str
    date_of_birth: Optional[date]
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": 1,
                "full_name": "John Doe",
                "email": "john@example.com",
                "phone": "+1-234-567-8900",
                "address": "123 Main Street",
                "city": "New York",
                "country": "United States",
                "date_of_birth": "1990-01-15",
                "created_at": "2026-02-07T10:00:00",
                "updated_at": "2026-02-07T10:00:00"
            }
        }