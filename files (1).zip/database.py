import os
from dotenv import load_dotenv

load_dotenv()

# Database URL - Using SQLite for simplicity (can be changed to PostgreSQL, MySQL, etc.)
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite:///./user_data.db"
)

# Example for PostgreSQL:
# DATABASE_URL = "postgresql://user:password@localhost/user_database"

# Example for MySQL:
# DATABASE_URL = "mysql+pymysql://user:password@localhost/user_database"